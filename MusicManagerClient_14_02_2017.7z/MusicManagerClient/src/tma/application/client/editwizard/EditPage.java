package tma.application.client.editwizard;

import java.io.IOException;
import java.net.MalformedURLException;
import java.rmi.RemoteException;
import java.util.List;

import javax.management.JMX;
import javax.management.MBeanServerConnection;
import javax.management.MalformedObjectNameException;
import javax.management.ObjectName;
import javax.management.remote.JMXConnector;
import javax.management.remote.JMXConnectorFactory;
import javax.management.remote.JMXServiceURL;

import org.eclipse.jface.layout.GridLayoutFactory;
import org.eclipse.jface.wizard.WizardPage;
import org.eclipse.swt.SWT;
import org.eclipse.swt.events.SelectionAdapter;
import org.eclipse.swt.events.SelectionEvent;
import org.eclipse.swt.layout.GridData;
import org.eclipse.swt.layout.GridLayout;
import org.eclipse.swt.widgets.Button;
import org.eclipse.swt.widgets.Combo;
import org.eclipse.swt.widgets.Composite;
import org.eclipse.swt.widgets.FileDialog;
import org.eclipse.swt.widgets.Label;
import org.eclipse.swt.widgets.Shell;
import org.eclipse.swt.widgets.Text;

import tma.application.DAO.GenreDAO;
import tma.application.client.parts.Client;
import tma.application.entities.Genre;

public class EditPage extends WizardPage {
	private static final String[] FILTER_EXTS = { "*.mp3", "*.midi", "*.*" };
	private Composite container;
	protected String fileName = "No chosen file", filePath = Client.table.getItem(Client.table.getSelectionIndex()).getText(2);
	protected Label lblName, lblGenre, lblFile;
	protected Text txtName;
	protected Combo cboGenre;
	protected Button btnChooseFile;
	protected GridLayout gl_shell;

	protected EditPage(String pageName) {
		super(pageName);
		setTitle("Update");
		setDescription("Update a song");
	}


	@Override
	public void createControl(Composite parent) {
		container = new Composite(parent, SWT.NULL);
		GridLayoutFactory.fillDefaults().applyTo(container);
		container.setSize(400, 165);
		gl_shell = new GridLayout(8, false);
		gl_shell.verticalSpacing = 10;
		container.setLayout(gl_shell);

		lblName = new Label(container, SWT.NONE);
		lblName.setLayoutData(new GridData(SWT.LEFT, SWT.CENTER, false, false, 1, 1));
		lblName.setText("Name: ");

		txtName = new Text(container, SWT.BORDER);
		txtName.setLayoutData(new GridData(SWT.FILL, SWT.FILL, true, false, 7, 1));
		txtName.setText(Client.table.getItem(Client.table.getSelectionIndex()).getText(1));

		lblGenre = new Label(container, SWT.NONE);
		lblGenre.setLayoutData(new GridData(SWT.LEFT, SWT.CENTER, false, false, 1, 1));
		lblGenre.setText("Genre: ");
		cboGenre = new Combo(container, SWT.DROP_DOWN | SWT.READ_ONLY);
		cboGenre.setLayoutData(new GridData(SWT.FILL, SWT.CENTER, false, false, 7, 1));
		try {
			JMXServiceURL url = new JMXServiceURL(Client.JMX_CONNECT);
			JMXConnector jmxc = JMXConnectorFactory.connect(url, null);
			MBeanServerConnection mbsc = jmxc.getMBeanServerConnection();
			ObjectName genreMbean = new ObjectName("bean:name=Genre");
			GenreDAO genre = JMX.newMBeanProxy(mbsc, genreMbean, GenreDAO.class, true);
			List<Genre> lists = genre.getAllGenre();
			for (Genre genre_ : lists) {
				cboGenre.add(genre_.getGenreName());
				cboGenre.setData(genre_.getGenreName(), genre_.getGenreId());
			}
			cboGenre.setText(Client.table.getItem(Client.table.getSelectionIndex()).getText(3));
		} catch (RemoteException e1) {
			e1.printStackTrace();
		} catch (MalformedURLException e1) {
			e1.printStackTrace();
		} catch (IOException e1) {
			e1.printStackTrace();
		} catch (MalformedObjectNameException e1) {
			e1.printStackTrace();
		}

		btnChooseFile = new Button(container, SWT.NONE);
		btnChooseFile.setLayoutData(new GridData(SWT.LEFT, SWT.CENTER, false, false, 1, 1));
		btnChooseFile.setText("Choose file...");
		btnChooseFile.addSelectionListener(new SelectionAdapter() {
			@Override
			public void widgetSelected(SelectionEvent e) {
				Shell shell = new Shell();

				FileDialog dialog = new FileDialog(shell);
				dialog.setFilterExtensions(FILTER_EXTS);
				if (dialog.open() != null) {
					fileName = dialog.getFileName();
					filePath = dialog.getFilterPath() + "\\" + fileName;
					lblFile.setText(filePath);
				}
			}
		});

		lblFile = new Label(container, SWT.NONE);
		lblFile.setLayoutData(new GridData(SWT.FILL, SWT.CENTER, true, false, 7, 1));
		lblFile.setText(filePath);
		
		setControl(container);
	}

}
