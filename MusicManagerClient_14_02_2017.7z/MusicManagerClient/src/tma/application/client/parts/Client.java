
package tma.application.client.parts;

import javax.inject.Inject;
import javax.management.JMX;
import javax.management.MBeanServerConnection;
import javax.management.MalformedObjectNameException;
import javax.management.ObjectName;
import javax.management.remote.JMXConnector;
import javax.management.remote.JMXConnectorFactory;
import javax.management.remote.JMXServiceURL;

import java.io.IOException;
import java.io.Serializable;
import java.net.MalformedURLException;
import java.net.URI;
import java.net.URISyntaxException;
import java.rmi.RemoteException;
import java.text.SimpleDateFormat;
import java.util.List;

import javax.annotation.PostConstruct;

import org.apache.activemq.broker.BrokerFactory;
import org.apache.activemq.broker.BrokerService;
import org.eclipse.e4.ui.services.EMenuService;
import org.eclipse.swt.SWT;
import org.eclipse.swt.widgets.Composite;
import org.eclipse.swt.widgets.Table;
import org.eclipse.swt.widgets.TableColumn;
import org.eclipse.swt.widgets.TableItem;
import org.springframework.context.support.GenericXmlApplicationContext;

import tma.application.DAO.SongDAO;
import tma.application.entities.Song;

public class Client implements Serializable {
	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;
	public static final String JMX_CONNECT = "service:jmx:rmi://127.0.0.1/jndi/rmi://127.0.0.1:6222/musicmanager15";
	public static Table table;

	@Inject
	public Client() {
	}

	@PostConstruct
	public void postConstruct(Composite parent, EMenuService menu) throws URISyntaxException, Exception {
		table = new Table(parent, SWT.BORDER | SWT.V_SCROLL | SWT.H_SCROLL | SWT.FULL_SELECTION);
		table.setHeaderVisible(true);
		table.setLinesVisible(true);
		menu.registerContextMenu(table, "musicmanagerclient.popupmenu.popupmenu");
		String[] titles = { "ID", "Name", "Path", "Genre", "Date" };
		Integer[] titlesSize = { 0, 225, 295, 100, 150 };
		for (int i = 0; i < titles.length; i++) {
			TableColumn colunm = new TableColumn(table, SWT.NULL);
			colunm.setText(titles[i]);
			colunm.setWidth(titlesSize[i]);
			if (i == 0) {
				colunm.setResizable(false);
			}
		}

		List<Song> lists = null;
		try {
			JMXServiceURL url = new JMXServiceURL(Client.JMX_CONNECT);
			JMXConnector jmxc = JMXConnectorFactory.connect(url, null);
			MBeanServerConnection mbsc = jmxc.getMBeanServerConnection();
			ObjectName songMbean = new ObjectName("bean:name=Song");
			SongDAO song = JMX.newMBeanProxy(mbsc, songMbean, SongDAO.class, true);
			lists = song.getAllSong();
		} catch (RemoteException e) {
			e.printStackTrace();
		} catch (MalformedURLException e) {
			e.printStackTrace();
		} catch (IOException e) {
			e.printStackTrace();
		} catch (MalformedObjectNameException e) {
			e.printStackTrace();
		}
		SimpleDateFormat df = new SimpleDateFormat("hh:mm:ss dd/MM/yyyy");
		for (Song song_ : lists) {
			TableItem tableItem = new TableItem(table, SWT.NONE);
			tableItem.setText(new String[] { Integer.toString(song_.getSongId()), song_.getSongName(),
					song_.getSongUrlFile(), song_.getGenre().getGenreName(), df.format(song_.getSongUpdateDate()) });
		}
		GenericXmlApplicationContext ctx = new GenericXmlApplicationContext();  
	    ctx.load("classpath:applicationContext.xml");  
	    ctx.refresh();  
	}

}