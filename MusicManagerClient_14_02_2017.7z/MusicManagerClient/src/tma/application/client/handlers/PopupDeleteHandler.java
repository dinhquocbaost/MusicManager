 
package tma.application.client.handlers;

import java.io.IOException;
import java.net.MalformedURLException;
import java.rmi.RemoteException;

import javax.management.JMX;
import javax.management.MBeanServerConnection;
import javax.management.MalformedObjectNameException;
import javax.management.ObjectName;
import javax.management.remote.JMXConnector;
import javax.management.remote.JMXConnectorFactory;
import javax.management.remote.JMXServiceURL;

import org.eclipse.e4.core.di.annotations.Execute;
import tma.application.DAO.SongDAO;
import tma.application.client.parts.Client;

public class PopupDeleteHandler {
	@Execute
	public void execute() {
		try {
			JMXServiceURL url = new JMXServiceURL(Client.JMX_CONNECT);
			JMXConnector jmxc = JMXConnectorFactory.connect(url, null);
			MBeanServerConnection mbsc = jmxc.getMBeanServerConnection();
			ObjectName songMbean = new ObjectName("bean:name=Song");
			SongDAO song = JMX.newMBeanProxy(mbsc, songMbean, SongDAO.class, true);
			if(Client.table.getSelectionIndex() != -1){
				song.deleteSong(Integer.parseInt(Client.table.getItem(Client.table.getSelectionIndex()).getText(0)));
				Client.table.remove(Client.table.getSelectionIndex());
			}
		} catch (RemoteException e) {
			e.printStackTrace();
		} catch (MalformedURLException e) {
			e.printStackTrace();
		} catch (IOException e) {
			e.printStackTrace();
		} catch (MalformedObjectNameException e) {
			e.printStackTrace();
		}
	}
		
}