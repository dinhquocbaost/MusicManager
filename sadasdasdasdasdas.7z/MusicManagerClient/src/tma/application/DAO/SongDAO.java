package tma.application.DAO;

import java.rmi.Remote;
import java.rmi.RemoteException;
import java.util.Date;
import java.util.List;

public interface SongDAO extends Remote {
	public Integer addSong(int genreId, String songName, String songUrlFile) throws RemoteException;

	public void updateSong(int songId, int genreId, String songName, String songUrlFile) throws RemoteException;

	public void deleteSong(int songId) throws RemoteException;
	
	public List<Integer> getAllSongId() throws RemoteException;
	
	public String getSongName(int songId) throws RemoteException;
	
	public String getSongUrl(int songId) throws RemoteException;
	
	public Date getDate(int songId) throws RemoteException;
	
	public Integer getGenreId(int songId) throws RemoteException;
	
	public String getGenreName(int genreId) throws RemoteException;
	
	public Integer getMaxId() throws RemoteException;
}
