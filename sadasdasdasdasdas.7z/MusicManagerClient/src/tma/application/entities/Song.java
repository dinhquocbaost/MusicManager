package tma.application.entities;

import java.util.Date;


public class Song {

	private int songId;

	private String songName;

	private String songUrlFile;
	
	private Date songUpdateDate;
	
	private int genreId;

	public Song() {
	}

	public int getGenreId() {
		return genreId;
	}

	public void setGenreId(int genreId) {
		this.genreId = genreId;
	}

	public Song(int songId, String songName, Date dateUpdate, int genreId) {
		this.songId = songId;
		this.songName = songName;
		this.songUpdateDate = dateUpdate;
		this.genreId = genreId;
	}

	public int getSongId() {
		return songId;
	}

	public void setSongId(int songId) {
		this.songId = songId;
	}

	public String getSongName() {
		return songName;
	}

	public void setSongName(String songName) {
		this.songName = songName;
	}

	public String getSongUrlFile() {
		return songUrlFile;
	}

	public void setSongUrlFile(String songUrlFile) {
		this.songUrlFile = songUrlFile;
	}

	public Date getSongUpdateDate() {
		return songUpdateDate;
	}

	public void setSongUpdateDate(Date songUpdateDate) {
		this.songUpdateDate = songUpdateDate;
	}
}
