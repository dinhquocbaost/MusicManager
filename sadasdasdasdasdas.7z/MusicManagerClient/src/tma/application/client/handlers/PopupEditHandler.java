 
package tma.application.client.handlers;

import org.eclipse.e4.core.di.annotations.Execute;
import org.eclipse.jface.window.Window;
import org.eclipse.swt.widgets.Composite;

import tma.application.client.editwizard.EditDialog;
import tma.application.client.editwizard.EditWizard;

public class PopupEditHandler {
	@Execute
	public void execute(Composite parent) {
		EditDialog editDialog = new EditDialog (parent.getShell(), new EditWizard());
		editDialog.setPageSize(400, 105);
		if (editDialog.open() == Window.OK) {
			System.out.println("OK pressed!");
		} else {
			System.out.println("Cancel pressed!");
		}
	}
		
}