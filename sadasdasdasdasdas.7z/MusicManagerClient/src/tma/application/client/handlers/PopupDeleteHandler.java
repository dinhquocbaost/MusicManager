 
package tma.application.client.handlers;

import javax.management.JMX;
import javax.management.MBeanServerConnection;
import javax.management.ObjectName;
import javax.management.remote.JMXConnector;
import javax.management.remote.JMXConnectorFactory;
import javax.management.remote.JMXServiceURL;

import org.eclipse.e4.core.di.annotations.Execute;
import tma.application.DAO.SongDAO;
import tma.application.client.parts.Client;

public class PopupDeleteHandler {
	@Execute
	public void execute() {
		System.out.println();
		JMXServiceURL url;
		try {
			url = new JMXServiceURL(Client.JMX_CONNECT);
			JMXConnector jmxc = JMXConnectorFactory.connect(url);
			MBeanServerConnection mbsc = jmxc.getMBeanServerConnection();
			ObjectName songMbean = new ObjectName("bean:name=Song");
			SongDAO song = JMX.newMXBeanProxy(mbsc, songMbean, SongDAO.class, true);
			song.deleteSong(Integer.parseInt(Client.table.getItem(Client.table.getSelectionIndex()).getText()));
			Client.table.remove(Client.table.getSelectionIndex());
		}catch (Exception e) {
			e.printStackTrace();
		}
	}
		
}