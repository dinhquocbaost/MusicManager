 
package tma.application.client.handlers;

import org.eclipse.e4.core.di.annotations.Execute;
import org.eclipse.jface.window.Window;
import org.eclipse.swt.SWT;
import org.eclipse.swt.widgets.Composite;
import org.eclipse.swt.widgets.MessageBox;

import tma.application.client.editwizard.EditWizard;
import tma.application.client.wizard.AddDialog;

public class AddGenreHandler {
	@Execute
	public void execute(Composite parent) {
		AddDialog wizardDialog = new AddDialog(parent.getShell(), new EditWizard());
		wizardDialog.setPageSize(400, 105);
		if (wizardDialog.open() == Window.OK) {
        	MessageBox messageBox = new MessageBox(parent.getShell(), SWT.ICON_INFORMATION | SWT.OK);
        	messageBox.setText("Updated!");
        	messageBox.setMessage("Updated!");
        	messageBox.open();
        } else {
        }
	}
		
}