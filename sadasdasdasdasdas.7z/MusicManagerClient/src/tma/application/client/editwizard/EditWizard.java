package tma.application.client.editwizard;

import java.io.IOException;
import java.net.MalformedURLException;
import java.rmi.RemoteException;
import java.text.SimpleDateFormat;
import java.util.Date;

import javax.management.JMX;
import javax.management.MBeanServerConnection;
import javax.management.MalformedObjectNameException;
import javax.management.ObjectName;
import javax.management.remote.JMXConnector;
import javax.management.remote.JMXConnectorFactory;
import javax.management.remote.JMXServiceURL;

import org.eclipse.jface.wizard.Wizard;
import org.eclipse.swt.widgets.TableItem;

import tma.application.DAO.SongDAO;
import tma.application.client.parts.Client;

public class EditWizard extends Wizard {
	protected EditPage editPage;

	
	public EditWizard() {
		super();
		setNeedsProgressMonitor(true);
	}
	
	@Override
    public String getWindowTitle() {
            return "Update";
    }

	
	@Override
	public void addPages() {
		editPage = new EditPage("Edit page");
		addPage(editPage);
	}
	
	@Override
	public boolean performFinish() {
		try {
			JMXServiceURL url = new JMXServiceURL(Client.JMX_CONNECT);
			JMXConnector jmxc = JMXConnectorFactory.connect(url, null);
			MBeanServerConnection mbsc = jmxc.getMBeanServerConnection();
			ObjectName songMbean = new ObjectName("bean:name=Song");
			SongDAO song = JMX.newMBeanProxy(mbsc, songMbean, SongDAO.class, true);
			if (editPage.txtName.getText().toString()=="" || editPage.filePath == "") {
				return false;
			}else{
				SimpleDateFormat simpleDateFormat = new SimpleDateFormat("yyyy-MM-dd hh:mm:ss");
				Date date = new Date();
				String formatDate = simpleDateFormat.format(date);
				song.updateSong(Integer.parseInt(Client.table.getItem(Client.table.getSelectionIndex()).getText(0)),
						Integer.parseInt(editPage.cboGenre.getData(editPage.cboGenre.getText()).toString()),
						editPage.txtName.getText(), editPage.filePath);
				TableItem item = Client.table.getSelection()[0];
				item.setText(new String[] {song.getMaxId().toString(), editPage.txtName.getText(), editPage.filePath, editPage.cboGenre.getText(), formatDate});
			}
		} catch (RemoteException e) {
			e.printStackTrace();
		} catch (MalformedURLException e) {
			e.printStackTrace();
		} catch (IOException e) {
			e.printStackTrace();
		} catch (MalformedObjectNameException e) {
			e.printStackTrace();
		}
		return true;
	}

}
