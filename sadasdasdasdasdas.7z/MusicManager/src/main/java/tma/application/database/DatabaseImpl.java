package tma.application.database;

import java.io.File;
import java.rmi.RemoteException;
import java.rmi.server.UnicastRemoteObject;
import java.util.EnumSet;

import org.hibernate.boot.Metadata;
import org.hibernate.boot.MetadataSources;
import org.hibernate.boot.registry.StandardServiceRegistryBuilder;
import org.hibernate.service.ServiceRegistry;
import org.hibernate.tool.hbm2ddl.SchemaExport;
import org.hibernate.tool.schema.TargetType;
import org.springframework.context.ApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;

import tma.application.database.DatabaseImpl;

public class DatabaseImpl extends UnicastRemoteObject implements Database {
	public DatabaseImpl() throws RemoteException {
	}

	private static final long serialVersionUID = 1L;
	private static final String SCRIPT_FILE = "src/main/resources/exportScript.sql";

	public void dropDataBase(SchemaExport export, Metadata metadata) throws RemoteException {
		EnumSet<TargetType> targetTypes = EnumSet.of(TargetType.DATABASE, TargetType.SCRIPT, TargetType.STDOUT);
		export.drop(targetTypes, metadata);
	}

	public void createDataBase(SchemaExport export, Metadata metadata) throws RemoteException {
		EnumSet<TargetType> targetTypes = EnumSet.of(TargetType.DATABASE, TargetType.SCRIPT, TargetType.STDOUT);
		SchemaExport.Action action = SchemaExport.Action.CREATE;
		export.execute(targetTypes, action, metadata);
		System.out.println("Export OK");
	}

	@SuppressWarnings("resource")
	public void runCreateDatabase() throws RemoteException {
		ApplicationContext context = new ClassPathXmlApplicationContext("beans.xml");
		Database db = (Database) context.getBean("databaseImplBean");
		String configFileName = "hibernate.cfg.xml";
		ServiceRegistry serviceRegistry = new StandardServiceRegistryBuilder().configure(configFileName).build();
		Metadata metadata = new MetadataSources(serviceRegistry).getMetadataBuilder().build();
		SchemaExport export = db.getSchemaExport();
		System.out.println("Drop Database...");
		dropDataBase(export, metadata);
		System.out.println("Create Database...");
		createDataBase(export, metadata);
	}

	public SchemaExport getSchemaExport() throws RemoteException {
		SchemaExport export = new SchemaExport();
		File outputFile = new File(SCRIPT_FILE);
		String outputFilePath = outputFile.getAbsolutePath();
		System.out.println("Export file: " + outputFilePath);
		export.setDelimiter(";");
		export.setOutputFile(outputFilePath);
		export.setHaltOnError(false);
		return export;
	}
}
