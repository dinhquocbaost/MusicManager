package tma.application.entities;

import java.io.Serializable;
import java.util.List;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.OneToMany;
import javax.persistence.Table;

@Entity
@Table(name = "genre")
public class Genre implements Serializable {

	/**
	 * 
	 */
	private static final long serialVersionUID = -2651498402397229641L;

	@OneToMany(fetch = FetchType.LAZY, mappedBy = "genre")
	private List<Song> songs;

	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	@Column(name = "g_id")
	private int genreId;

	@Column(name = "g_name", nullable = false)
	private String genreName;

	public Genre() {
	}

	public Genre(String genreName) {
		this.genreName = genreName;
	}

	public Genre(int genreId, String genreName) {
		this.genreId = genreId;
		this.genreName = genreName;
	}

	public List<Song> getSongs() {
		return songs;
	}

	public void setSongs(List<Song> songs) {
		this.songs = songs;
	}

	public int getGenreId() {
		return genreId;
	}

	public void setGenreId(int genreId) {
		this.genreId = genreId;
	}

	public String getGenreName() {
		return genreName;
	}

	public void setGenreName(String genreName) {
		this.genreName = genreName;
	}

}
