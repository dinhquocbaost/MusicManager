package tma.application.server;

import org.springframework.context.support.ClassPathXmlApplicationContext;

public class Server implements ServerBean {

	@SuppressWarnings("resource")
	public void start() throws Exception {
		new ClassPathXmlApplicationContext("spring-config.xml");
		
	}

	public void stop() throws Exception {
		
	}

}
