package tma.application.server;

public interface ServerBean {
	void start() throws Exception;

    void stop() throws Exception;
}
