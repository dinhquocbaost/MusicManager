package tma.application.DAO;

import java.rmi.RemoteException;
import java.util.Date;
import java.util.List;

import org.hibernate.Session;
import org.hibernate.Transaction;
import org.hibernate.query.Query;
import org.springframework.context.ApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;

import tma.application.entities.Genre;
import tma.application.entities.Song;
import tma.application.utils.HibernateUtils;

public class SongDAOImpl implements SongDAO {

	public SongDAOImpl() throws RemoteException {
		super();
	}

	private Session session = null;
	private Transaction tx = null;

	@SuppressWarnings("resource")
	public Integer addSong(int genreId, String songName, String songUrlFile) throws RemoteException {
		session = HibernateUtils.getSessionFactory().openSession();
		try {
			tx = session.beginTransaction();
			ApplicationContext context = new ClassPathXmlApplicationContext("beans.xml");
			Genre genre = (Genre) context.getBean("genreBean");
			genre.setGenreId(genreId);
			Song song = (Song) context.getBean("songBean");
			song.setGenre(genre);
			song.setSongName(songName);
			song.setSongUrlFile(songUrlFile);
			song.setSongUpdateDate(new Date());
			session.save(song);
			tx.commit();
			return song.getSongId();
		} catch (Exception e) {
			if (tx != null) {
				tx.rollback();
			}
		} finally {
			if (session != null) {
				session.close();
			}
		}
		return null;
	}

	@SuppressWarnings("rawtypes")
	public void updateSong(int songId, int genreId, String songName, String songUrlFile) throws RemoteException {
		session = HibernateUtils.getSessionFactory().openSession();
		try {
			tx = session.beginTransaction();
			String hql = "UPDATE " + Song.class.getName()
					+ " SET genre.genreId = :genreId, songName = :songName, songUpdateDate = :songUpdateDate, songUrlFile = :songUrlFile WHERE songId = :songId";
			Query query = session.createQuery(hql);
			query.setParameter("genreId", genreId);
			query.setParameter("songName", songName);
			query.setParameter("songId", songId);
			query.setParameter("songUrlFile", songUrlFile);
			query.setParameter("songUpdateDate", new Date());
			query.executeUpdate();
			tx.commit();
		} catch (Exception e) {
			if (tx != null) {
				tx.rollback();
			}
		} finally {
			if (session != null) {
				session.close();
			}
		}

	}

	@SuppressWarnings("rawtypes")
	public void deleteSong(int songId) throws RemoteException {
		session = HibernateUtils.getSessionFactory().openSession();
		try {
			tx = session.beginTransaction();
			String hql = "DELETE FROM " + Song.class.getName() + " WHERE songId = :songId";
			Query query = session.createQuery(hql);
			query.setParameter("songId", songId);
			query.executeUpdate();
			tx.commit();
		} catch (Exception e) {
			if (tx != null) {
				tx.rollback();
			}
		} finally {
			if (session != null) {
				session.close();
			}
		}

	}

	@SuppressWarnings("unchecked")
	public List<Integer> getAllSongId() throws RemoteException {
		session = HibernateUtils.getSessionFactory().openSession();
		try {
			tx = session.beginTransaction();
			String hql = "SELECT songId FROM " + Song.class.getName() + " ORDER BY songId ASC";
			List<Integer> lists = session.createQuery(hql).getResultList();
			return lists;
		} catch (Exception e) {
			if(tx != null){
				tx.rollback();
			}
			throw new IllegalArgumentException();
		} finally {
			if(session != null){
				session.close();
			}
		}
	}

	@SuppressWarnings({ "unchecked", "rawtypes" })
	public String getSongName(int songId) throws RemoteException {
		session = HibernateUtils.getSessionFactory().openSession();
		try {
			tx = session.beginTransaction();
			String hql = "SELECT songName FROM " + Song.class.getName() + " WHERE songId = :songId";
			Query query = session.createQuery(hql);
			query.setParameter("songId", songId);
			List<String> songName = query.getResultList();
			return songName.get(0);
		} catch (Exception e) {
			if(tx != null){
				tx.rollback();
			}
			throw new IllegalArgumentException();
		} finally {
			if(session != null){
				session.close();
			}
		}
	}

	@SuppressWarnings({ "rawtypes", "unchecked" })
	public String getSongUrl(int songId) throws RemoteException {
		session = HibernateUtils.getSessionFactory().openSession();
		try {
			tx = session.beginTransaction();
			String hql = "SELECT songUrlFile FROM " + Song.class.getName() + " WHERE songId = :songId";
			Query query = session.createQuery(hql);
			query.setParameter("songId", songId);
			List<String> songUrlFile = query.getResultList();
			return songUrlFile.get(0);
		} catch (Exception e) {
			if(tx != null){
				tx.rollback();
			}
			throw new IllegalArgumentException();
		} finally {
			if(session != null){
				session.close();
			}
		}
	}

	@SuppressWarnings({ "rawtypes", "unchecked" })
	public Date getDate(int songId) throws RemoteException {
		session = HibernateUtils.getSessionFactory().openSession();
		try {
			tx = session.beginTransaction();
			String hql = "SELECT songUpdateDate FROM " + Song.class.getName() + " WHERE songId = :songId";
			Query query = session.createQuery(hql);
			query.setParameter("songId", songId);
			List<Date> songUpdateDate = query.getResultList();
			return songUpdateDate.get(0);
		} catch (Exception e) {
			if(tx != null){
				tx.rollback();
			}
			throw new IllegalArgumentException();
		} finally {
			if(session != null){
				session.close();
			}
		}
	}

	@SuppressWarnings({ "unchecked", "rawtypes" })
	public Integer getGenreId(int songId) throws RemoteException {
		session = HibernateUtils.getSessionFactory().openSession();
		try {
			tx = session.beginTransaction();
			String hql = "SELECT genre.genreId FROM " + Song.class.getName() + " WHERE songId = :songId";
			Query query = session.createQuery(hql);
			query.setParameter("songId", songId);
			List<Integer> genreId = query.getResultList();
			return genreId.get(0);
		} catch (Exception e) {
			if(tx != null){
				tx.rollback();
			}
			throw new IllegalArgumentException();
		} finally {
			if(session != null){
				session.close();
			}
		}
	}

	@SuppressWarnings({ "unchecked", "rawtypes" })
	public String getGenreName(int genreId) throws RemoteException {
		session = HibernateUtils.getSessionFactory().openSession();
		try {
			tx = session.beginTransaction();
			String hql = "SELECT genreName FROM " + Genre.class.getName() + " WHERE genreId = :genreId";
			Query query = session.createQuery(hql);
			query.setParameter("genreId", genreId);
			List<String> genreName = query.getResultList();
			return genreName.get(0);
		} catch (Exception e) {
			if(tx != null){
				tx.rollback();
			}
			throw new IllegalArgumentException();
		} finally {
			if(session != null){
				session.close();
			}
		}
	}

	@SuppressWarnings({ "unchecked", "rawtypes" })
	public Integer getMaxId() throws RemoteException {
		session = HibernateUtils.getSessionFactory().openSession();
		try {
			tx = session.beginTransaction();
			String hql = "SELECT max(songId) FROM " + Song.class.getName();
			Query query = session.createQuery(hql);
			List<Integer> maxSongId = query.getResultList();
			return maxSongId.get(0);
		} catch (Exception e) {
			if(tx != null){
				tx.rollback();
			}
			throw new IllegalArgumentException();
		} finally {
			if(session != null){
				session.close();
			}
		}
	}
	
	

}
