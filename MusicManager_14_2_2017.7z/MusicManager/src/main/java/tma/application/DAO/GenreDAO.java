package tma.application.DAO;

import java.rmi.Remote;
import java.rmi.RemoteException;
import java.util.List;

import tma.application.entities.Genre;


public interface GenreDAO extends Remote {
	public void addGenre(String genreName) throws RemoteException;

	public void updateGenre(int genreId, String genreName) throws RemoteException;

	public void deleteGenre(int genreId) throws RemoteException;
	
	public int getGenreId(String genreName) throws RemoteException;
	
	public List<Genre> getAllGenre() throws RemoteException;
}
