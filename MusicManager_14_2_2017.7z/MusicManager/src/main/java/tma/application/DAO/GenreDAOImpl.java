package tma.application.DAO;

import java.rmi.RemoteException;
import java.util.List;
import org.hibernate.Query;
import org.hibernate.Session;
import org.hibernate.Transaction;
import org.springframework.context.ApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;

import tma.application.entities.Genre;
import tma.application.utils.HibernateUtils;

public class GenreDAOImpl implements GenreDAO {

	public GenreDAOImpl() throws RemoteException {
	}

	private Session session = null;
	private Transaction tx = null;

	@SuppressWarnings({ "resource" })
	public void addGenre(String genreName) throws RemoteException {
		session = HibernateUtils.getSessionFactory().openSession();
		try {
			tx = session.beginTransaction();
			String hql = "SELECT COUNT(*) FROM " + Genre.class.getName() + " WHERE genreName = :genreName";
			Query query = session.createQuery(hql);
			query.setParameter("genreName", genreName);
			if (Integer.parseInt(query.list().get(0).toString()) == 0) {
				ApplicationContext context = new ClassPathXmlApplicationContext("beans.xml");
				Genre genre = (Genre) context.getBean("genreBean");
				genre.setGenreName(genreName);
				session.save(genre);
				tx.commit();
			}

		} catch (Exception e) {
			if (tx != null) {
				tx.rollback();
			}
		} finally {
			if (session != null) {
				session.close();
			}
		}
	}

	public void updateGenre(int genreId, String genreName) throws RemoteException {
		session = HibernateUtils.getSessionFactory().openSession();
		try {
			tx = session.beginTransaction();
			Genre genre = (Genre) session.get(Genre.class, genreId);
			genre.setGenreName(genreName);
			session.update(genre);
			tx.commit();
		} catch (Exception e) {
			if (tx != null) {
				tx.rollback();
			}
		} finally {
			if (session != null) {
				session.close();
			}
		}
	}

	public void deleteGenre(int genreId) throws RemoteException {
		session = HibernateUtils.getSessionFactory().openSession();
		try {
			tx = session.beginTransaction();
			Genre genre = (Genre) session.get(Genre.class, genreId);
			session.delete(genre);
			tx.commit();
		} catch (Exception e) {
			if (tx != null) {
				tx.rollback();
			}
		} finally {
			if (session != null) {
				session.close();
			}
		}
	}

	@SuppressWarnings({ "unchecked" })
	public int getGenreId(String genreName) throws RemoteException {
		session = HibernateUtils.getSessionFactory().openSession();
		try {
			tx = session.beginTransaction();
			String hql = "SELECT genreId FROM " + Genre.class.getName() + " WHERE genreName = :genreName";
			Query query = session.createQuery(hql);
			query.setParameter("genreName", genreName);
			List<Integer> result = query.list();
			return result.get(0);
		} catch (Exception e) {
			if (tx != null) {
				tx.rollback();
			}
			throw new ArrayIndexOutOfBoundsException();
		} finally {
			if (session != null) {
				session.close();
			}
		}
	}

	@SuppressWarnings("unchecked")
	public List<Genre> getAllGenre() throws RemoteException {
		session = HibernateUtils.getSessionFactory().openSession();
		try {
			tx = session.beginTransaction();
			String hql = "FROM " + Genre.class.getName();
			List<Genre> lists = session.createQuery(hql).list();
			return lists;
		} catch (Exception e) {
			// TODO: handle exception
		}
		return null;
	}

}
