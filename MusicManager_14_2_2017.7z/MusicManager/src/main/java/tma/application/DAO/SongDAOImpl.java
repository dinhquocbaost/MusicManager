package tma.application.DAO;

import java.net.URI;
import java.rmi.RemoteException;
import java.util.Date;
import java.util.List;

import org.apache.activemq.broker.BrokerFactory;
import org.apache.activemq.broker.BrokerService;
import org.hibernate.Session;
import org.hibernate.Transaction;
import org.springframework.context.ApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;

import tma.application.entities.Genre;
import tma.application.entities.Song;
import tma.application.jms.MyMessageSender;
import tma.application.utils.HibernateUtils;

public class SongDAOImpl implements SongDAO {

	public SongDAOImpl() throws RemoteException {
		super();
	}

	private Session session = null;
	private Transaction tx = null;
	private Song song;
	private Genre genre;

	@SuppressWarnings("resource")
	public Integer addSong(int genreId, String songName, String songUrlFile) throws RemoteException {
		session = HibernateUtils.getSessionFactory().openSession();
		try {
			tx = session.beginTransaction();
			ApplicationContext context = new ClassPathXmlApplicationContext("beans.xml");
			genre = (Genre) context.getBean("genreBean");
			genre.setGenreId(genreId);
			song = (Song) context.getBean("songBean");
			song.setGenre(genre);
			song.setSongName(songName);
			song.setSongUrlFile(songUrlFile);
			song.setSongUpdateDate(new Date());
			session.save(song);
			tx.commit();
			System.out.println("1-------------------------");
			try {
				ApplicationContext ctx=new ClassPathXmlApplicationContext("applicationContext.xml");
				ctx.getBean("jmsTemplate");
			    MyMessageSender sender=ctx.getBean("messageSender",MyMessageSender.class);  
			    sender.sendMessage("hello jms3");
			} catch (Exception e) {
				e.printStackTrace();
			}
		    System.out.println("5-----------------------");
			return song.getSongId();
		} catch (Exception e) {
			if (tx != null) {
				tx.rollback();
			}
		} finally {
			if (session != null) {
				session.close();
			}
		}
		return null;
	}

	public void updateSong(int songId, int genreId, String songName, String songUrlFile) throws RemoteException {
		session = HibernateUtils.getSessionFactory().openSession();
		try {
			tx = session.beginTransaction();
			genre = (Genre) session.get(Genre.class, genreId);
			song = (Song) session.get(Song.class, songId);
			song.setGenre(genre);
			song.setSongName(songName);
			song.setSongUrlFile(songUrlFile);
			song.setSongUpdateDate(new Date());
			tx.commit();
		} catch (Exception e) {
			if (tx != null) {
				tx.rollback();
			}
		} finally {
			if (session != null) {
				session.close();
			}
		}

	}

	public void deleteSong(int songId) throws RemoteException {
		session = HibernateUtils.getSessionFactory().openSession();
		try {
			tx = session.beginTransaction();
			song = (Song) session.get(Song.class, songId);
			session.delete(song);
			tx.commit();
		} catch (Exception e) {
			if (tx != null) {
				tx.rollback();
			}
		} finally {
			if (session != null) {
				session.close();
			}
		}

	}

	public String getSongName(int songId) throws RemoteException {
		session = HibernateUtils.getSessionFactory().openSession();
		try {
			tx = session.beginTransaction();
			song = (Song) session.get(Song.class, songId);
			return song.getSongName();
		} catch (Exception e) {
			if (tx != null) {
				tx.rollback();
			}
			throw new IllegalArgumentException();
		} finally {
			if (session != null) {
				session.close();
			}
		}
	}

	public String getSongUrl(int songId) throws RemoteException {
		session = HibernateUtils.getSessionFactory().openSession();
		try {
			tx = session.beginTransaction();
			song = (Song) session.get(Song.class, songId);
			return song.getSongUrlFile();
		} catch (Exception e) {
			if (tx != null) {
				tx.rollback();
			}
			throw new IllegalArgumentException();
		} finally {
			if (session != null) {
				session.close();
			}
		}
	}

	public Date getDate(int songId) throws RemoteException {
		session = HibernateUtils.getSessionFactory().openSession();
		try {
			tx = session.beginTransaction();
			song = (Song) session.get(Song.class, songId);
			return song.getSongUpdateDate();
		} catch (Exception e) {
			if (tx != null) {
				tx.rollback();
			}
			throw new IllegalArgumentException();
		} finally {
			if (session != null) {
				session.close();
			}
		}
	}

	public Integer getGenreId(int songId) throws RemoteException {
		session = HibernateUtils.getSessionFactory().openSession();
		try {
			tx = session.beginTransaction();
			song = (Song) session.get(Song.class, songId);
			return song.getGenreId();
		} catch (Exception e) {
			if (tx != null) {
				tx.rollback();
			}
			throw new IllegalArgumentException();
		} finally {
			if (session != null) {
				session.close();
			}
		}
	}

	public String getGenreName(int genreId) throws RemoteException {
		session = HibernateUtils.getSessionFactory().openSession();
		try {
			tx = session.beginTransaction();
			genre = (Genre) session.get(Genre.class, genreId);
			return genre.getGenreName();
		} catch (Exception e) {
			if (tx != null) {
				tx.rollback();
			}
			throw new IllegalArgumentException();
		} finally {
			if (session != null) {
				session.close();
			}
		}
	}

	@SuppressWarnings("unchecked")
	public List<Song> getAllSong() throws RemoteException {
		session = HibernateUtils.getSessionFactory().openSession();
		try {
			tx = session.beginTransaction();
			String hql = "FROM " + Song.class.getName() + " ORDER BY songId ASC";
			List<Song> lists = session.createQuery(hql).list();
			return lists;
		} catch (Exception e) {
			if (tx != null) {
				tx.rollback();
			}
			throw new IllegalArgumentException();
		}finally {
			if (session != null) {
				session.close();
			}
		}
	}
}
