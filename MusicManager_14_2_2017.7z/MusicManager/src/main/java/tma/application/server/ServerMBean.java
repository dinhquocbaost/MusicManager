package tma.application.server;

public interface ServerMBean {
	
	public void start() throws Exception;

    public void stop() throws Exception;
    
}
