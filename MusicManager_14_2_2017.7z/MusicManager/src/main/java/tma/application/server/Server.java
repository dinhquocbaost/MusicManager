package tma.application.server;

import org.springframework.context.support.ClassPathXmlApplicationContext;

public class Server implements ServerMBean {
	
	@SuppressWarnings("resource")
	public void start() throws Exception {
		System.out.println("STARTING SERVER...!");
		new ClassPathXmlApplicationContext("spring-config.xml");
		System.out.println("STARTED!");
		
	}

	public void stop() throws Exception {
	}

}
