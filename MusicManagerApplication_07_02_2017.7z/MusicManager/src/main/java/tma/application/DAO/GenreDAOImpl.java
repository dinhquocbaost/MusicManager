package tma.application.DAO;

import java.rmi.RemoteException;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.hibernate.Session;
import org.hibernate.Transaction;
import org.hibernate.query.Query;

import tma.application.entities.Genre;
import tma.application.utils.HibernateUtils;

public class GenreDAOImpl implements GenreDAO {

	public GenreDAOImpl() throws RemoteException {
	}

	private Session session = null;
	private Transaction tx = null;

	@SuppressWarnings({ "rawtypes" })
	public void addGenre(String genreName) throws RemoteException {
		session = HibernateUtils.getSessionFactory().openSession();
		List result;
		try {
			tx = session.beginTransaction();
			String hql = "SELECT COUNT(*) FROM " + Genre.class.getName() + " WHERE genreName = :genreName";
			Query query = session.createQuery(hql);
			query.setParameter("genreName", genreName);
			result = query.getResultList();
			System.out.println();
			if(Integer.parseInt(result.get(0).toString())==0){
				session.save(new Genre(genreName));
				tx.commit();
			}
			
		} catch (Exception e) {
			if (tx != null) {
				tx.rollback();
			}
		} finally {
			if (session != null) {
				session.close();
			}
		}
	}

	@SuppressWarnings("rawtypes")
	public void updateGenre(int genreId, String genreName) throws RemoteException {
		session = HibernateUtils.getSessionFactory().openSession();
		try {
			tx = session.beginTransaction();
			String hql = "UPDATE " + Genre.class.getName() + " SET genreName = :genreName WHERE genreId = :genreId";
			Query query = session.createQuery(hql);
			query.setParameter("genreName", genreName);
			query.setParameter("genreId", genreId);
			query.executeUpdate();
			tx.commit();
		} catch (Exception e) {
			if (tx != null) {
				tx.rollback();
			}
		} finally {
			if (session != null) {
				session.close();
			}
		}
	}

	@SuppressWarnings("rawtypes")
	public void deleteGenre(int genreId) throws RemoteException {
		session = HibernateUtils.getSessionFactory().openSession();
		try {
			tx = session.beginTransaction();
			String hql = "DELETE FROM " + Genre.class.getName() + " WHERE genreId = :genreId";
			Query query = session.createQuery(hql);
			query.setParameter("genreId", genreId);
			query.executeUpdate();
			tx.commit();
		} catch (Exception e) {
			if (tx != null) {
				tx.rollback();
			}
		} finally {
			if (session != null) {
				session.close();
			}
		}
	}

	@SuppressWarnings("unchecked")
	public Map<Integer, String> getAllGenre() throws RemoteException {
		session = HibernateUtils.getSessionFactory().openSession();
		try {
			tx = session.beginTransaction();
			Map<Integer, String> genreMap = new HashMap<Integer, String>();
			String hql = "FROM " + Genre.class.getName();
			List<Genre> lists = session.createQuery(hql).getResultList();
			for(Genre genre : lists){
				genreMap.put(genre.getGenreId(), genre.getGenreName());
			}
			return genreMap;
		} catch (Exception e) {
			if(tx != null){
				tx.rollback();
			}
			throw new ArrayIndexOutOfBoundsException();
		} finally {
			if(session != null){
				session.close();
			}
		}
	}

	@SuppressWarnings("unchecked")
	public String[] getAllGenreName() throws RemoteException {
		session = HibernateUtils.getSessionFactory().openSession();
		try {
			tx = session.beginTransaction();
			String hql = "SELECT genreName FROM " + Genre.class.getName();
			List<String> lists = session.createQuery(hql).getResultList();
			String[] result = new String[lists.size()];
			result = lists.toArray(result);
			return result;
		} catch (Exception e) {
			if(tx != null){
				tx.rollback();
			}
			throw new ArrayIndexOutOfBoundsException();
		} finally {
			if(session != null){
				session.close();
			}
		}
	}

	@SuppressWarnings({ "unchecked", "rawtypes" })
	public int getGenreId(String genreName) throws RemoteException {
		session = HibernateUtils.getSessionFactory().openSession();
		try {
			tx = session.beginTransaction();
			String hql = "SELECT genreId FROM " + Genre.class.getName() + " WHERE genreName = :genreName";
			Query query = session.createQuery(hql);
			query.setParameter("genreName", genreName);
			List<Integer> result = query.getResultList();
			return result.get(0);
		} catch (Exception e) {
			if(tx != null){
				tx.rollback();
			}
			throw new ArrayIndexOutOfBoundsException();
		} finally {
			if(session != null){
				session.close();
			}
		}
	}

}
