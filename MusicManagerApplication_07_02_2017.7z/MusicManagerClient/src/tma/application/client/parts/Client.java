
package tma.application.client.parts;

import javax.inject.Inject;
import javax.management.JMX;
import javax.management.MBeanServerConnection;
import javax.management.MalformedObjectNameException;
import javax.management.ObjectName;
import javax.management.remote.JMXConnector;
import javax.management.remote.JMXConnectorFactory;
import javax.management.remote.JMXServiceURL;

import java.io.IOException;
import java.io.Serializable;
import java.net.MalformedURLException;
import java.rmi.RemoteException;
import java.util.List;

import javax.annotation.PostConstruct;

import org.eclipse.e4.ui.services.EMenuService;
import org.eclipse.swt.SWT;
import org.eclipse.swt.widgets.Composite;
import org.eclipse.swt.widgets.Table;
import org.eclipse.swt.widgets.TableColumn;
import org.eclipse.swt.widgets.TableItem;

import tma.application.DAO.SongDAO;

public class Client implements Serializable {
	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;
	public static final String JMX_CONNECT = "service:jmx:rmi://localhost/jndi/rmi://localhost:10099/musicmanager2";
	public static Table table;

	@Inject
	public Client() {

	}

	@PostConstruct
	public void postConstruct(Composite parent, EMenuService menu) throws RemoteException {

		table = new Table(parent, SWT.BORDER | SWT.V_SCROLL | SWT.H_SCROLL | SWT.FULL_SELECTION);
		table.setHeaderVisible(true);
		table.setLinesVisible(true);
		
		menu.registerContextMenu(table, "musicmanagerclient.popupmenu.popupmenu");
		
		String[] titles = { "ID", "Name", "Path", "Genre", "Date" };
		Integer[] titlesSize = { 0, 225, 295, 100, 150 };
		for (int i = 0; i < titles.length; i++) {
			TableColumn colunm = new TableColumn(table, SWT.NULL);
			colunm.setText(titles[i]);
			colunm.setWidth(titlesSize[i]);
			if (i == 0) {
				colunm.setResizable(false);
			}
		}

		JMXServiceURL url;
		List<Integer> lists = null;
		SongDAO song = null;
		try {
			url = new JMXServiceURL(Client.JMX_CONNECT);
			JMXConnector jmxc = JMXConnectorFactory.connect(url, null);
			MBeanServerConnection mbsc = jmxc.getMBeanServerConnection();
			ObjectName songMbean = new ObjectName("bean:name=Song");
			song = JMX.newMBeanProxy(mbsc, songMbean, SongDAO.class, true);
			lists = song.getAllSongId();

		} catch (RemoteException e) {
			e.printStackTrace();
		} catch (MalformedURLException e) {
			e.printStackTrace();
		} catch (IOException e) {
			e.printStackTrace();
		} catch (MalformedObjectNameException e) {
			e.printStackTrace();
		}

		for (int i = 0; i < lists.size(); i++) {
			TableItem tableItem = new TableItem(table, SWT.NONE);
			tableItem.setText(new String[] { lists.get(i).toString(), song.getSongName(lists.get(i)),
					song.getSongUrl(lists.get(i)), song.getGenreName(song.getGenreId(lists.get(i))).toString(),
					song.getDate(lists.get(i)).toString() });
		}
		
		
	}

}