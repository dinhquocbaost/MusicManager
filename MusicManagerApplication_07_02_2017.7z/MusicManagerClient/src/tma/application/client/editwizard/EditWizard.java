package tma.application.client.editwizard;

import org.eclipse.jface.wizard.Wizard;

public class EditWizard extends Wizard {

	@Override
	public boolean performFinish() {
		// TODO Auto-generated method stub
		return false;
	}

}
