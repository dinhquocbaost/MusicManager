package tma.application.client.editwizard;

import org.eclipse.jface.wizard.WizardPage;
import org.eclipse.swt.widgets.Composite;

public class EditPage extends WizardPage {

	protected EditPage(String pageName) {
		super(pageName);
		setTitle("Update");
		setDescription("Update a song");
	}

	@Override
	public void createControl(Composite parent) {
		// TODO Auto-generated method stub
		
	}

}
