 
package tma.application.client.handlers;

import org.eclipse.e4.core.di.annotations.Execute;

public class PopupEditHandler {
	@Execute
	public void execute() {
		
	}
		
}