package tma.application.client.wizard;

import java.io.IOException;
import java.net.MalformedURLException;
import java.rmi.RemoteException;

import javax.management.JMX;
import javax.management.MBeanServerConnection;
import javax.management.MalformedObjectNameException;
import javax.management.ObjectName;
import javax.management.remote.JMXConnector;
import javax.management.remote.JMXConnectorFactory;
import javax.management.remote.JMXServiceURL;

import org.eclipse.jface.layout.GridLayoutFactory;
import org.eclipse.jface.wizard.WizardPage;
import org.eclipse.swt.SWT;
import org.eclipse.swt.events.SelectionAdapter;
import org.eclipse.swt.events.SelectionEvent;
import org.eclipse.swt.layout.GridData;
import org.eclipse.swt.layout.GridLayout;
import org.eclipse.swt.widgets.Button;
import org.eclipse.swt.widgets.Combo;
import org.eclipse.swt.widgets.Composite;
import org.eclipse.swt.widgets.FileDialog;
import org.eclipse.swt.widgets.Label;
import org.eclipse.swt.widgets.Shell;
import org.eclipse.swt.widgets.Text;

import tma.application.DAO.GenreDAO;
import tma.application.client.parts.Client;

public class AddPage extends WizardPage {

	private static final String[] FILTER_EXTS = { "*.mp3", "*.midi", "*.*" };
	protected String fileName = "No chosen file", filePath = "";
	protected Label lblName, lblGenre, lblFile;
	protected Text txtName;
	protected Combo cboGenre;
	protected Button btnChooseFile;
	protected GridLayout gl_shell;
	protected GridData gd_lblName, gd_txtName, gd_lblGenre, gd_cboGenre, gd_btnChooseFile, gd_lblFile;

	public AddPage() {
		super("wizardPage");
		setTitle("Add song");
		setDescription("Add a new song to libary");
	}

	@Override
	public void createControl(Composite parent) {

		Composite container = new Composite(parent, SWT.NULL);
		GridLayoutFactory.fillDefaults().applyTo(container);

		container.setSize(400, 165);

		gl_shell = new GridLayout(8, false);
		gl_shell.verticalSpacing = 10;
		container.setLayout(gl_shell);

		lblName = new Label(container, SWT.NONE);
		gd_lblName = new GridData(SWT.LEFT, SWT.CENTER, false, false, 1, 1);
		lblName.setLayoutData(gd_lblName);
		gd_lblName.widthHint = 50;
		lblName.setText("Name: ");

		txtName = new Text(container, SWT.BORDER);
		gd_txtName = new GridData(SWT.FILL, SWT.FILL, true, false, 7, 1);
		txtName.setLayoutData(gd_txtName);

		lblGenre = new Label(container, SWT.NONE);
		gd_lblGenre = new GridData(SWT.LEFT, SWT.CENTER, false, false, 1, 1);
		lblGenre.setLayoutData(gd_lblName);
		gd_lblGenre.widthHint = 50;
		lblGenre.setText("Genre: ");

		cboGenre = new Combo(container, SWT.DROP_DOWN | SWT.READ_ONLY);
		gd_cboGenre = new GridData(SWT.FILL, SWT.CENTER, false, false, 7, 1);
		cboGenre.setLayoutData(gd_cboGenre);
		JMXServiceURL url;
		try {
			url = new JMXServiceURL(Client.JMX_CONNECT);
			JMXConnector jmxc = JMXConnectorFactory.connect(url, null);
			MBeanServerConnection mbsc = jmxc.getMBeanServerConnection();
			ObjectName genreMbean = new ObjectName("bean:name=Genre");
			GenreDAO genre = JMX.newMBeanProxy(mbsc, genreMbean, GenreDAO.class, true);
			String[] lists = genre.getAllGenreName();
			cboGenre.setItems(lists);
			cboGenre.select(0);
		} catch (RemoteException e1) {
			// TODO Auto-generated catch block
			e1.printStackTrace();
		} catch (MalformedURLException e1) {
			// TODO Auto-generated catch block
			e1.printStackTrace();
		} catch (IOException e1) {
			// TODO Auto-generated catch block
			e1.printStackTrace();
		} catch (MalformedObjectNameException e1) {
			// TODO Auto-generated catch block
			e1.printStackTrace();
		}

		btnChooseFile = new Button(container, SWT.NONE);
		gd_btnChooseFile = new GridData(SWT.LEFT, SWT.CENTER, false, false, 1, 1);
		btnChooseFile.setLayoutData(gd_btnChooseFile);
		btnChooseFile.setText("Choose file...");
		btnChooseFile.addSelectionListener(new SelectionAdapter() {
			@Override
			public void widgetSelected(SelectionEvent e) {
				Shell shell = new Shell();

				FileDialog dialog = new FileDialog(shell);
				dialog.setFilterExtensions(FILTER_EXTS);
				if (dialog.open() != null) {
					fileName = dialog.getFileName();
					filePath = dialog.getFilterPath() + "\\" + fileName;
					lblFile.setText(fileName);
				}
			}
		});

		lblFile = new Label(container, SWT.NONE);
		gd_lblFile = new GridData(SWT.FILL, SWT.CENTER, true, false, 7, 1);
		lblFile.setLayoutData(gd_lblFile);
		lblFile.setText(fileName);

		setControl(container);

	}

}
