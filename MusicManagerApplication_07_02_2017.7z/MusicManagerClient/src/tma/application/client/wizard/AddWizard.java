package tma.application.client.wizard;

import java.io.IOException;
import java.net.MalformedURLException;
import java.rmi.RemoteException;
import java.util.Date;

import javax.management.JMX;
import javax.management.MBeanServerConnection;
import javax.management.MalformedObjectNameException;
import javax.management.ObjectName;
import javax.management.remote.JMXConnector;
import javax.management.remote.JMXConnectorFactory;
import javax.management.remote.JMXServiceURL;

import org.eclipse.jface.wizard.Wizard;
import org.eclipse.swt.SWT;
import org.eclipse.swt.widgets.TableItem;

import tma.application.DAO.GenreDAO;
import tma.application.DAO.SongDAO;
import tma.application.client.parts.Client;

public class AddWizard extends Wizard {

	protected AddPage addPage;
	
	
	public AddWizard() {
		super();
		setNeedsProgressMonitor(true);
	}
	
	@Override
    public String getWindowTitle() {
            return "Add new song";
    }
	 
	  @Override
      public void addPages() {
		  addPage = new AddPage();
          addPage(addPage);
      }
	
	@Override
	public boolean performFinish() {
		JMXServiceURL url;
		try {
			url = new JMXServiceURL(Client.JMX_CONNECT);
			JMXConnector jmxc = JMXConnectorFactory.connect(url, null);
			MBeanServerConnection mbsc = jmxc.getMBeanServerConnection();
			ObjectName genreMbean = new ObjectName("bean:name=Genre");
			GenreDAO genre = JMX.newMBeanProxy(mbsc, genreMbean, GenreDAO.class, true);
			ObjectName songMbean = new ObjectName("bean:name=Song");
			SongDAO song = JMX.newMBeanProxy(mbsc, songMbean, SongDAO.class, true);
			if (addPage.txtName.getText().toString()=="" || addPage.filePath == "") {
				return false;
			}else{
				song.addSong(genre.getGenreId(addPage.cboGenre.getText().toString()), addPage.txtName.getText().toString(), addPage.filePath);
				TableItem tableItem = new TableItem(Client.table, SWT.NONE);
				tableItem.setText(new String[] { song.getMaxId().toString(), addPage.txtName.getText().toString(), addPage.filePath, addPage.cboGenre.getText().toString(), new Date().toString() });
			}
		} catch (RemoteException e) {
			e.printStackTrace();
		} catch (MalformedURLException e) {
			e.printStackTrace();
		} catch (IOException e) {
			e.printStackTrace();
		} catch (MalformedObjectNameException e) {
			e.printStackTrace();
		}
		return true;
	}

}
