package tma.application.DAO;

import java.rmi.RemoteException;
import java.rmi.server.UnicastRemoteObject;
import java.util.Date;

import org.hibernate.Session;
import org.hibernate.Transaction;
import org.hibernate.query.Query;
import org.springframework.context.ApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;

import tma.application.entities.Genre;
import tma.application.entities.Song;
import tma.application.utils.HibernateUtils;

public class SongDAOImpl extends UnicastRemoteObject implements SongDAO {

	private static final long serialVersionUID = 1L;

	public SongDAOImpl() throws RemoteException {
	}

	private Session session = null;
	private Transaction tx = null;

	@SuppressWarnings("resource")
	public void addSong(int genreId, String songName) throws RemoteException {
		session = HibernateUtils.getSessionFactory().openSession();
		try {
			ApplicationContext context = new ClassPathXmlApplicationContext("beans.xml");
			Genre genre = (Genre) context.getBean("genreBean");
			genre.setGenreId(genreId);
			Song song = (Song) context.getBean("songBean");
			song.setGenre(genre);
			song.setSongName(songName);
			song.setSongUpdateDate(new Date());
			tx = session.beginTransaction();
			session.save(song);
			tx.commit();
		} catch (Exception e) {
			if (tx != null) {
				tx.rollback();
			}
		} finally {
			if (session != null) {
				session.close();
			}
		}
	}

	@SuppressWarnings("rawtypes")
	public void updateSong(int songId, int genreId, String songName) throws RemoteException {
		session = HibernateUtils.getSessionFactory().openSession();
		try {
			tx = session.beginTransaction();
			String hql = "UPDATE " + Song.class.getName()
					+ " SET genre.genreId = :genreId, songName = :songName, songUpdateDate = :songUpdateDate WHERE songId = :songId";
			Query query = session.createQuery(hql);
			query.setParameter("genreId", genreId);
			query.setParameter("songName", songName);
			query.setParameter("songId", songId);
			query.setParameter("songUpdateDate", new Date());
			query.executeUpdate();
			tx.commit();
		} catch (Exception e) {
			if (tx != null) {
				tx.rollback();
			}
		} finally {
			if (session != null) {
				session.close();
			}
		}

	}

	@SuppressWarnings("rawtypes")
	public void deleteSong(int songId) throws RemoteException {
		session = HibernateUtils.getSessionFactory().openSession();
		try {
			tx = session.beginTransaction();
			String hql = "DELETE FROM " + Song.class.getName() + " WHERE songId = :songId";
			Query query = session.createQuery(hql);
			query.setParameter("songId", songId);
			query.executeUpdate();
			tx.commit();
		} catch (Exception e) {
			if (tx != null) {
				tx.rollback();
			}
		} finally {
			if (session != null) {
				session.close();
			}
		}

	}

}
