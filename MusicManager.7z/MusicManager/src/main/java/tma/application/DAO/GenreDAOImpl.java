package tma.application.DAO;

import java.rmi.RemoteException;
import java.rmi.server.UnicastRemoteObject;

import org.hibernate.Session;
import org.hibernate.Transaction;
import org.hibernate.query.Query;

import tma.application.entities.Genre;
import tma.application.utils.HibernateUtils;

public class GenreDAOImpl extends UnicastRemoteObject implements GenreDAO {

	private static final long serialVersionUID = 1L;

	public GenreDAOImpl() throws RemoteException {
	}

	private Session session = null;
	private Transaction tx = null;

	public void addGenre(String genreName) throws RemoteException {
		session = HibernateUtils.getSessionFactory().openSession();
		try {
			tx = session.beginTransaction();
			session.save(new Genre(genreName));
			tx.commit();
		} catch (Exception e) {
			if (tx != null) {
				tx.rollback();
			}
		} finally {
			if (session != null) {
				session.close();
			}
		}
	}

	@SuppressWarnings("rawtypes")
	public void updateGenre(int genreId, String genreName) throws RemoteException {
		session = HibernateUtils.getSessionFactory().openSession();
		try {
			tx = session.beginTransaction();
			String hql = "UPDATE " + Genre.class.getName() + " SET genreName = :genreName WHERE genreId = :genreId";
			Query query = session.createQuery(hql);
			query.setParameter("genreName", genreName);
			query.setParameter("genreId", genreId);
			query.executeUpdate();
			tx.commit();
		} catch (Exception e) {
			if (tx != null) {
				tx.rollback();
			}
		} finally {
			if (session != null) {
				session.close();
			}
		}
	}

	@SuppressWarnings("rawtypes")
	public void deleteGenre(int genreId) throws RemoteException {
		session = HibernateUtils.getSessionFactory().openSession();
		try {
			tx = session.beginTransaction();
			String hql = "DELETE FROM " + Genre.class.getName() + " WHERE genreId = :genreId";
			Query query = session.createQuery(hql);
			query.setParameter("genreId", genreId);
			query.executeUpdate();
			tx.commit();
		} catch (Exception e) {
			if (tx != null) {
				tx.rollback();
			}
		} finally {
			if (session != null) {
				session.close();
			}
		}
	}

}
