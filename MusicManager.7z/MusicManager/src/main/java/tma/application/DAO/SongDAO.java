package tma.application.DAO;

import java.rmi.Remote;
import java.rmi.RemoteException;

public interface SongDAO extends Remote {
	public void addSong(int genreId, String songName) throws RemoteException;

	public void updateSong(int songId, int genreId, String songName) throws RemoteException;

	public void deleteSong(int songId) throws RemoteException;
}
