package tma.application.client;

import java.rmi.Naming;
import java.rmi.RemoteException;

import tma.application.DAO.GenreDAO;
import tma.application.DAO.SongDAO;
public class Client {

	private static final int PORT = 5029;
	
	public static void main(String[] args) throws RemoteException {

		try {
			GenreDAO genre = (GenreDAO) Naming.lookup("rmi://localhost:" + PORT + "/genre");
			genre.addGenre("Rock");
			SongDAO song = (SongDAO) Naming.lookup("rmi://localhost:" + PORT + "/song");
			song.deleteSong(8);
		} catch (Exception e) {
			throw new RemoteException();
		}

	}

}
