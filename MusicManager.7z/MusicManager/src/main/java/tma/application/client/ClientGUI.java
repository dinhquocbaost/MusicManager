package tma.application.client;

public class ClientGUI {
	
	
	
	public static void main(String[] args) {
		
		

	}

}
