package tma.application.server;

import java.rmi.Naming;
import java.rmi.RemoteException;
import java.rmi.registry.LocateRegistry;

import tma.application.DAO.GenreDAO;
import tma.application.DAO.GenreDAOImpl;
import tma.application.DAO.SongDAO;
import tma.application.DAO.SongDAOImpl;

public class Server {

	private static final int PORT = 5030;
	private static final String HOST = "rmi://localhost:" + PORT + "/";

	public static void main(String[] args) throws RemoteException {

		try {
			LocateRegistry.createRegistry(PORT);
			GenreDAO genre = new GenreDAOImpl();
			Naming.rebind(HOST + "genre", genre);
			SongDAO song = new SongDAOImpl();
			Naming.rebind(HOST + "song", song);
		} catch (Exception e) {
			throw new RemoteException(e.getMessage());
		}

	}

}
