alter table song drop foreign key FKqnp9okfx0rdqnhwrkfuiki6uu;
drop table if exists genre;
drop table if exists song;
create table genre (g_id integer not null auto_increment, g_name varchar(255), primary key (g_id));
create table song (s_id integer not null auto_increment, s_name varchar(255) not null, s_update_date datetime, s_url_file varchar(255), g_id integer, primary key (s_id));
alter table song add constraint FKqnp9okfx0rdqnhwrkfuiki6uu foreign key (g_id) references genre (g_id);
