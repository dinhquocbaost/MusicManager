package tma.application.server;

import org.springframework.context.ApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;

public class Server {
	
	@SuppressWarnings({ "resource" })
	public static void main(String[] args){
		System.out.println("Server starting...");
		ApplicationContext context = new ClassPathXmlApplicationContext("spring-config.xml");
	    context.getBean("factory");
		System.out.println("Server started!");
	}

}
