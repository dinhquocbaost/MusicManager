 
package tma.application.client.handlers;

import org.eclipse.e4.core.di.annotations.Execute;
import org.eclipse.jface.window.Window;
import org.eclipse.swt.widgets.Composite;

import tma.application.client.editwizard.EditWizard;
import tma.application.client.wizard.AddDialog;

public class AddGenreHandler {
	@Execute
	public void execute(Composite parent) {
		AddDialog wizardDialog = new AddDialog(parent.getShell(), new EditWizard());
		wizardDialog.setPageSize(400, 105);
		if (wizardDialog.open() == Window.OK) {
        } else {
        }
	}
		
}