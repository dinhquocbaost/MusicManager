 
package tma.application.client.handlers;

import org.eclipse.e4.core.di.annotations.Execute;
import org.eclipse.jface.window.Window;
import org.eclipse.swt.widgets.Composite;

import tma.application.client.wizard.AddDialog;
import tma.application.client.wizard.AddWizard;

public class AddHandler {
	@Execute
	public void execute(Composite parent) {
		AddDialog wizardDialog = new AddDialog(parent.getShell(),
                new AddWizard());
		wizardDialog.setPageSize(400, 105);
        if (wizardDialog.open() == Window.OK) {
//        	MessageBox messageBox = new MessageBox(parent.getShell(), SWT.ICON_INFORMATION | SWT.OK);
//        	messageBox.setText("Completed!");
//        	messageBox.setMessage("Added a new song!");
//        	messageBox.open();
        } else {
        }
	}
		
}