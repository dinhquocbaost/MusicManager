package tma.application.entities;

import java.io.Serializable;
import java.util.Date;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.Table;
import javax.persistence.Temporal;
import javax.persistence.TemporalType;

@Entity
@Table(name = "song")
public class Song implements Serializable {

	/**
	 * 
	 */
	private static final long serialVersionUID = -2423791225360074894L;

	@ManyToOne(fetch = FetchType.EAGER)
	@JoinColumn(name = "g_id")
	private Genre genre;

	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	@Column(name = "s_id")
	private int songId;

	@Column(name = "s_name", nullable = false)
	private String songName;

	@Column(name = "s_url_file", nullable = false)
	private String songUrlFile;

	@Temporal(TemporalType.TIMESTAMP)
	@Column(name = "s_update_date", nullable = false)
	private Date songUpdateDate;

	public Song() {
	}

	public Song(Genre genre, String songName) {
		this.genre = genre;
		this.songName = songName;
	}

	public Song(int songId, String songName, Date dateUpdate) {
		this.songId = songId;
		this.songName = songName;
		this.songUpdateDate = dateUpdate;
	}

	public Song(Genre genre, String songName, Date dateUpdate) {
		this.genre = genre;
		this.songName = songName;
		this.songUpdateDate = dateUpdate;
	}

	public Genre getGenre() {
		return genre;
	}

	public void setGenre(Genre genre) {
		this.genre = genre;
	}

	public int getSongId() {
		return songId;
	}

	public void setSongId(int songId) {
		this.songId = songId;
	}

	public String getSongName() {
		return songName;
	}

	public void setSongName(String songName) {
		this.songName = songName;
	}

	public String getSongUrlFile() {
		return songUrlFile;
	}

	public void setSongUrlFile(String songUrlFile) {
		this.songUrlFile = songUrlFile;
	}

	public Date getSongUpdateDate() {
		return songUpdateDate;
	}

	public void setSongUpdateDate(Date songUpdateDate) {
		this.songUpdateDate = songUpdateDate;
	}

	public int getGenreId() {
		return this.genre.getGenreId();
	}

}
