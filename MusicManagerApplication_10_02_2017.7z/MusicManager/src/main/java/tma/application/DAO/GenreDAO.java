package tma.application.DAO;

import java.rmi.Remote;
import java.rmi.RemoteException;
import java.util.Map;


public interface GenreDAO extends Remote {
	public void addGenre(String genreName) throws RemoteException;

	public void updateGenre(int genreId, String genreName) throws RemoteException;

	public void deleteGenre(int genreId) throws RemoteException;
	
	public Map<Integer, String> getAllGenre() throws RemoteException;
	
	public String[] getAllGenreName() throws RemoteException;
	
	public int getGenreId(String genreName) throws RemoteException;
	
	public void test() throws RemoteException;
}
