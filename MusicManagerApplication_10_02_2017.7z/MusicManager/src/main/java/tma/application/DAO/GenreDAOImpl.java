package tma.application.DAO;

import java.rmi.RemoteException;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.hibernate.Session;
import org.hibernate.Transaction;
import org.hibernate.query.Query;
import org.springframework.context.ApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;

import tma.application.entities.Genre;
import tma.application.utils.HibernateUtils;

public class GenreDAOImpl implements GenreDAO {

	public GenreDAOImpl() throws RemoteException {
	}

	private Session session = null;
	private Transaction tx = null;

	@SuppressWarnings({ "rawtypes", "resource" })
	public void addGenre(String genreName) throws RemoteException {
		session = HibernateUtils.getSessionFactory().openSession();
		try {
			tx = session.beginTransaction();
			String hql = "SELECT COUNT(*) FROM " + Genre.class.getName() + " WHERE genreName = :genreName";
			Query query = session.createQuery(hql);
			query.setParameter("genreName", genreName);
			if (Integer.parseInt(query.getResultList().get(0).toString()) == 0) {
				ApplicationContext context = new ClassPathXmlApplicationContext("beans.xml");
				Genre genre = (Genre) context.getBean("genreBean");
				genre.setGenreName(genreName);
				session.save(genre);
				tx.commit();
			}

		} catch (Exception e) {
			if (tx != null) {
				tx.rollback();
			}
		} finally {
			if (session != null) {
				session.close();
			}
		}
	}

	public void updateGenre(int genreId, String genreName) throws RemoteException {
		session = HibernateUtils.getSessionFactory().openSession();
		try {
			tx = session.beginTransaction();
			Genre genre = (Genre) session.get(Genre.class, genreId);
			genre.setGenreName(genreName);
			session.update(genre);
			tx.commit();
		} catch (Exception e) {
			if (tx != null) {
				tx.rollback();
			}
		} finally {
			if (session != null) {
				session.close();
			}
		}
	}

	public void deleteGenre(int genreId) throws RemoteException {
		session = HibernateUtils.getSessionFactory().openSession();
		try {
			tx = session.beginTransaction();
			Genre genre = (Genre) session.get(Genre.class, genreId);
			session.delete(genre);
			tx.commit();
		} catch (Exception e) {
			if (tx != null) {
				tx.rollback();
			}
		} finally {
			if (session != null) {
				session.close();
			}
		}
	}

	@SuppressWarnings("unchecked")
	public Map<Integer, String> getAllGenre() throws RemoteException {
		session = HibernateUtils.getSessionFactory().openSession();
		try {
			tx = session.beginTransaction();
			Map<Integer, String> genreMap = new HashMap<Integer, String>();
			String hql = "FROM " + Genre.class.getName();
			List<Genre> lists = session.createQuery(hql).getResultList();
			for (Genre genre : lists) {
				genreMap.put(genre.getGenreId(), genre.getGenreName());
			}
			return genreMap;
		} catch (Exception e) {
			if (tx != null) {
				tx.rollback();
			}
			throw new ArrayIndexOutOfBoundsException();
		} finally {
			if (session != null) {
				session.close();
			}
		}
	}

	@SuppressWarnings("unchecked")
	public String[] getAllGenreName() throws RemoteException {
		session = HibernateUtils.getSessionFactory().openSession();
		try {
			tx = session.beginTransaction();
			String hql = "SELECT genreName FROM " + Genre.class.getName();
			List<String> lists = session.createQuery(hql).getResultList();
			String[] result = new String[lists.size()];
			result = lists.toArray(result);
			return result;
		} catch (Exception e) {
			if (tx != null) {
				tx.rollback();
			}
			throw new ArrayIndexOutOfBoundsException();
		} finally {
			if (session != null) {
				session.close();
			}
		}
	}

	@SuppressWarnings({ "unchecked", "rawtypes" })
	public int getGenreId(String genreName) throws RemoteException {
		session = HibernateUtils.getSessionFactory().openSession();
		try {
			tx = session.beginTransaction();
			String hql = "SELECT genreId FROM " + Genre.class.getName() + " WHERE genreName = :genreName";
			Query query = session.createQuery(hql);
			query.setParameter("genreName", genreName);
			List<Integer> result = query.getResultList();
			return result.get(0);
		} catch (Exception e) {
			if (tx != null) {
				tx.rollback();
			}
			throw new ArrayIndexOutOfBoundsException();
		} finally {
			if (session != null) {
				session.close();
			}
		}
	}

	public void test() {
		System.out.println("asdasdasdasd");

	}

}
