package tma.application.main;

import tma.application.server.Server;

public class StartServer {

	public static void main(String[] args) throws Exception {
		
		Server server = new Server();
		server.start();

	}

}
