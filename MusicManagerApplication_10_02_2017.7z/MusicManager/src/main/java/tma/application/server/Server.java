package tma.application.server;

import org.springframework.context.support.ClassPathXmlApplicationContext;

public class Server implements ServerMBean {
	
	@SuppressWarnings("resource")
	public void start() throws Exception {
		System.out.println("SERVER STARTED!");
		new ClassPathXmlApplicationContext("spring-config.xml");
		
	}

	public void stop() throws Exception {
	}

}
