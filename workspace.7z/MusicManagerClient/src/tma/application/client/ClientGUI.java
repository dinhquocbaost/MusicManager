package tma.application.client;

import org.eclipse.swt.widgets.Display;
import org.eclipse.swt.widgets.Shell;
import org.eclipse.swt.SWT;
import org.eclipse.swt.layout.GridLayout;
import org.eclipse.swt.layout.GridData;
import org.eclipse.swt.widgets.Table;
import org.eclipse.swt.widgets.TableColumn;
import org.eclipse.jface.viewers.TableViewerColumn;
import org.eclipse.swt.graphics.Point;
import org.eclipse.jface.viewers.TableViewer;

public class ClientGUI {

	protected Shell shell;
	private Table table;
	private TableViewer tableViewer;
	private TableColumn tblclmnName;
	private TableViewerColumn tableViewerColumn;
	private TableColumn tblclmnGenre;
	private TableViewerColumn tableViewerColumn_1;
	private TableColumn tblclmnDate;
	private TableViewerColumn tableViewerColumn_2;

	/**
	 * Launch the application.
	 * @param args
	 */
	public static void main(String[] args) {
		try {
			ClientGUI window = new ClientGUI();
			window.open();
		} catch (Exception e) {
			e.printStackTrace();
		}
	}

	/**
	 * Open the window.
	 */
	public void open() {
		Display display = Display.getDefault();
		createContents();
		shell.open();
		shell.layout();
		while (!shell.isDisposed()) {
			if (!display.readAndDispatch()) {
				display.sleep();
			}
		}
	}

	/**
	 * Create contents of the window.
	 */
	protected void createContents() {
		shell = new Shell();
		shell.setMinimumSize(new Point(800, 600));
		shell.setSize(800, 600);
		shell.setText("SWT Application");
		shell.setLayout(new GridLayout(1, false));
		
		TopGUI topGUI = new TopGUI(shell, SWT.NONE);
		GridData gd_topGUI = new GridData(SWT.FILL, SWT.FILL, false, false, 1, 1);
		gd_topGUI.widthHint = 423;
		topGUI.setLayoutData(gd_topGUI);
		
		tableViewer = new TableViewer(shell, SWT.BORDER | SWT.FULL_SELECTION);
		table = tableViewer.getTable();
		table.setLinesVisible(true);
		table.setHeaderVisible(true);
		table.setLayoutData(new GridData(SWT.FILL, SWT.FILL, true, true, 1, 1));
		
		tableViewerColumn = new TableViewerColumn(tableViewer, SWT.NONE);
		tblclmnName = tableViewerColumn.getColumn();
		tblclmnName.setWidth(571);
		tblclmnName.setText("Name");
		
		tableViewerColumn_1 = new TableViewerColumn(tableViewer, SWT.NONE);
		tblclmnGenre = tableViewerColumn_1.getColumn();
		tblclmnGenre.setWidth(100);
		tblclmnGenre.setText("Genre");
		
		tableViewerColumn_2 = new TableViewerColumn(tableViewer, SWT.NONE);
		tblclmnDate = tableViewerColumn_2.getColumn();
		tblclmnDate.setWidth(100);
		tblclmnDate.setText("Date");

	}
}
