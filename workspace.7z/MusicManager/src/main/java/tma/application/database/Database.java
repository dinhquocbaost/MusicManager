package tma.application.database;

import java.rmi.Remote;
import java.rmi.RemoteException;

import org.hibernate.boot.Metadata;
import org.hibernate.tool.hbm2ddl.SchemaExport;

public interface Database extends Remote {
	public SchemaExport getSchemaExport() throws RemoteException;

	public void runCreateDatabase() throws RemoteException;

	public void createDataBase(SchemaExport export, Metadata metadata) throws RemoteException;

	public void dropDataBase(SchemaExport export, Metadata metadata) throws RemoteException;
}
