package tma.application.client;

import java.rmi.Naming;
import java.rmi.RemoteException;
import java.util.List;

import tma.application.DAO.GenreDAO;
import tma.application.DAO.SongDAO;
import tma.application.entities.Song;
public class Client {

	private static final int PORT = 5044;
	
	public static void main(String[] args) throws RemoteException {
		try {
			GenreDAO genre = (GenreDAO) Naming.lookup("rmi://localhost:" + PORT + "/genre");
			genre.addGenre("Rock");
			SongDAO song = (SongDAO) Naming.lookup("rmi://localhost:" + PORT + "/song");
			song.addSong(1, "Song name", "Path");
			List<Song> lists = song.getAllSong();
			for (Song song2 : lists) {
				System.out.println(song2.getGenreId());
			}
			System.out.println("Song name: " + song.getASong(1).getGenreId());
		} catch (Exception e) {
			e.printStackTrace();
		}

	}

}
