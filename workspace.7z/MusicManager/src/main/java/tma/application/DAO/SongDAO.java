package tma.application.DAO;

import java.rmi.Remote;
import java.rmi.RemoteException;
import java.util.List;

import tma.application.entities.Song;

public interface SongDAO extends Remote {
	public void addSong(int genreId, String songName, String songUrlFile) throws RemoteException;

	public void updateSong(int songId, int genreId, String songName) throws RemoteException;

	public void deleteSong(int songId) throws RemoteException;
	
	public List<Song> getAllSong() throws RemoteException;
	
	public Song getASong(int songId) throws RemoteException;
}
