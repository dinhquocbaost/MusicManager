package tma.application.DAO;

import java.rmi.Remote;
import java.rmi.RemoteException;

public interface GenreDAO extends Remote {
	public void addGenre(String genreName) throws RemoteException;

	public void updateGenre(int genreId, String genreName) throws RemoteException;

	public void deleteGenre(int genreId) throws RemoteException;
}
