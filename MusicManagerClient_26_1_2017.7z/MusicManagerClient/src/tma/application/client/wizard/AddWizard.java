package tma.application.client.wizard;

import org.eclipse.jface.wizard.Wizard;

public class AddWizard extends Wizard {

	protected AddPage addPage;
	
	
	public AddWizard() {
		super();
		setNeedsProgressMonitor(true);
	}
	
	@Override
    public String getWindowTitle() {
            return "Add new song";
    }
	 
	  @Override
      public void addPages() {
              addPage(new AddPage());
      }
	
	@Override
	public boolean performFinish() {
		
		return true;
	}

}
