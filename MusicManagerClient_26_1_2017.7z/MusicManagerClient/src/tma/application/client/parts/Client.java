 
package tma.application.client.parts;

import javax.inject.Inject;
import javax.annotation.PostConstruct;

import org.eclipse.jface.viewers.TableViewer;
import org.eclipse.jface.viewers.TableViewerColumn;
import org.eclipse.swt.SWT;
import org.eclipse.swt.layout.GridData;
import org.eclipse.swt.layout.GridLayout;
import org.eclipse.swt.widgets.Composite;
import org.eclipse.swt.widgets.Table;
import org.eclipse.swt.widgets.TableColumn;
import org.eclipse.swt.widgets.TableItem;

public class Client {
	
	private Table table;
	private TableViewer tableViewer;
	private TableViewerColumn tableViewerColumnName, tableViewerColumnGenre, tableViewerColumnDate;
	private TableColumn tblclmnName, tblclmnGenre, tblclmnDate;
	
	@Inject
	public Client() {
		
	}
	
	@PostConstruct
	public void postConstruct(Composite parent) {
		
		parent.setLayout(new GridLayout(1, false));
		tableViewer = new TableViewer(parent, SWT.BORDER | SWT.FULL_SELECTION);
		table = tableViewer.getTable();
		table.setLinesVisible(true);
		table.setHeaderVisible(true);
		table.setLayoutData(new GridData(SWT.FILL, SWT.FILL, true, true, 1, 1));

		// Table column "Name"
		tableViewerColumnName = new TableViewerColumn(tableViewer, SWT.NONE);
		tblclmnName = tableViewerColumnName.getColumn();
		tblclmnName.setWidth(470);
		tblclmnName.setText("Name");

		// Table column "Genre"
		tableViewerColumnGenre = new TableViewerColumn(tableViewer, SWT.NONE);
		tblclmnGenre = tableViewerColumnGenre.getColumn();
		tblclmnGenre.setWidth(150);
		tblclmnGenre.setText("Genre");

		// Table column "Date"
		tableViewerColumnDate = new TableViewerColumn(tableViewer, SWT.NONE);
		tblclmnDate = tableViewerColumnDate.getColumn();
		tblclmnDate.setWidth(150);
		tblclmnDate.setText("Date");
		
		TableItem tableItem = new TableItem(table, SWT.NONE);
		tableItem.setText(new String[] {"sdad", "sadasdas", "sdasdsadadadas"});
		TableItem tableItem2 = new TableItem(table, SWT.NONE);
		tableItem2.setText(new String[] {"sdad", "sadasdas", "sdasdsadadadas"});
		
		
		
	}
	
	
	
	
}